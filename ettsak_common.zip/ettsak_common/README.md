# Common plays that should be run on all hosts
- add-lfrootca-play: Install LFRootCA on the host.
- oem-agent-play: Install Oracle Cloud Control agent on the host and connect it to OEM. No discovery is made.
- nftables-play: Configures nftables correctly.
