#!/bin/bash
set -e
set -x
export AGENT_BASE={{ oem_agent_base_dir }}
export AGENT_HOME=$AGENT_BASE/agent_13.5.0.0.0
export JAVA_HOME=$AGENT_HOME/jdk
export PATH=$JAVA_HOME/bin:$PATH

java -jar ./emclikit.jar -install_dir={{ emcli_base }}
./emcli setup -url={{ emcli_oms_url }} -username={{ oms_login_user }} -password={{ oms_login_password }} -trustall -nocertvalidate -autologin

exit $?
